# obra. — Protótipo 03

Protótipo privado e estático, em português de Portugal, com quatro perfis de demonstração. Todos os pagamentos, contratos, avaliações, produtos e prestadores são fictícios.

## Experimentar

O menu «Exemplos» permite começar no comparativo, numa obra já contratada ou numa proposta de adenda de 40 000 € para 42 000 €. «Continuar» muda apenas o perfil/ecrã para o próximo interveniente; nunca aprova ou movimenta valores automaticamente.

O estado fica em `localStorage`, no navegador. As fotografias permanecem apenas na memória da página e nunca são enviadas. «Reiniciar» limpa a demonstração. A troca de perfis não representa autenticação ou autorização de produção.

## Âmbito implementado

- Comparativo com trabalhos incluídos/excluídos e preços globais sem IVA.
- Área manual e cálculo largura × altura − vãos, revisão de publicação e volume 3D ilustrativo.
- Entregas iniciais das duas partes antes de revelar contactos fictícios.
- Aceitação bilateral, financiamento, tranches e avaliação.
- Adendas com aceitação do cliente, financiamento adicional e acerto da comissão pelo pintor.
- Compra declarada e devoluções de materiais, sem certificação da aplicação.
- Desistências encaminhadas para análise, divergências e resolução bilateral sobre o saldo retido.
- Registo local de atividade e separação de comissão, cauções e fundos da obra.

## Regras confirmadas e hipóteses

Confirmado: comissão de 3% sobre o valor sem IVA, mínimo 150 €, sem teto; IVA da comissão acresce; devida normalmente pelo pintor; acréscimos de valor implicam acerto da comissão; existem cauções de ambas as partes.

Hipótese A, ainda não confirmada: fee e caução do pintor separados; cada caução equivale ao fee base; caução do cliente imputada no financiamento; caução do pintor devolvida separadamente com a primeira tranche. A devolução extingue essa garantia para fases posteriores.

Adendas nesta versão: comissão adicional = comissão sobre o novo total − comissão já recebida. O mínimo não é cobrado novamente. A ativação exige aprovação bilateral e receção dos acertos. Os trabalhos adicionais têm fase própria antes da receção final; valores das tranches anteriores mantêm-se. Cauções iniciais não são aumentadas automaticamente. Estas opções de fluxo são propostas para validação, não decisões jurídicas fechadas.

Reduções são encaminhadas para análise, sem abatimento ou devolução automática da comissão. A regra comercial de perda de valor equivalente ao fee pela parte desistente não é executada automaticamente: causa, exceções, cumulação com comissão e destino das cauções ainda exigem definição.

Resolução por acordo nesta demonstração: ambas as partes aceitam a mesma repartição do saldo retido; comissão recebida mantém-se; caução do pintor ainda retida é devolvida. Inclui valores adicionais já financiados, mesmo quando a adenda ainda aguarda o acerto da comissão. Não recupera pagamentos anteriores.

Todos os valores da obra estão sem IVA nesta simulação. O IVA de 23% da comissão é meramente ilustrativo. Um financiamento real terá de incluir o IVA aplicável à obra e o tratamento fiscal correto de cada operação.

## Limites e próxima implementação

Sem reconstrução por fotografias, IA técnica, consulta real de fichas, identificação, validação de assinaturas, integração com pagamentos ou base de dados de produção. O volume é uma representação paramétrica aproximada, configurada manualmente; não identifica um prédio real nem é reconstruído a partir de fotografias. Não está definida a tolerância para alterações de área. A plataforma não é apresentada como garante da execução da obra.

O projeto não substitui a validação contratual/fiscal do modelo, a seleção de parceiro de pagamentos nem controlos de acesso no servidor.

## Verificação

`npm test` verifica contabilidade, estados, cauções, desbloqueio de contactos, adendas, mínimos, rejeição, resolução bilateral, devoluções e persistência. `npm run check` verifica a sintaxe dos módulos. Testes de interface usam um DOM simulado: não substituem teste visual num navegador.

Código em `dist/core.mjs` (regras), `dist/app.mjs` (interface), `dist/styles.css` e `dist/index.html`. A versão é estática e não precisa de instalação ou compilação.

## Levantamento da obra — versão 03

O cliente configura pisos, dimensões aproximadas, fachadas com varandas e fachadas junto a prédios contíguos. O volume acompanha estas escolhas, mas as suas dimensões não alteram automaticamente a área do pedido.

As quatro fachadas podem ser incluídas ou excluídas. Até vinte superfícies adicionais permitem registar varandas, tetos, elementos metálicos e outras zonas, com quantidade. Área = (largura × segunda dimensão − vãos por unidade) × quantidade. A área manual substitui a soma; a diferença fica visível. Cada valor tem origem declarada: estimativa, medição do cliente ou planta; nenhuma é certificada pela plataforma.

O estado e as dificuldades de acesso são registados em opções estruturadas e observações, sujeitos a revisão antes da exposição ao pintor. As fotografias privadas têm zona e tipo (vista geral/pormenor), limite de 12 × 8 MB e podem ser removidas. Não são enviadas, persistidas nem mostradas no perfil público do pintor. Ainda não existe anonimização automática.

Uma alteração do pedido incrementa a revisão, suspende a publicação e impede adjudicar propostas antigas. Depois da revisão da plataforma, o pintor B12 pode reconfirmar a sua proposta de demonstração. Os preços por m² das propostas anteriores preservam a área sobre a qual foram calculados. As propostas A34 e C57 só demonstram o cenário inicial.

Os dados locais da versão 02 são migrados para a versão 03 sem modificar pagamentos, adendas ou cauções. Pedidos antigos já em revisão continuam a exigir reconfirmação. Não se faz reconstrução de estados históricos que a versão anterior não registava.

## Protótipo 04 — início, exclusões e esclarecimentos

- Prazo para iniciar separado da duração. Contagem proposta: após acordo bilateral e financiamento confirmado. Migração não inventa disponibilidade para propostas antigas.
- Meios de acesso equivalentes (andaimes, plataforma, cordas, outro ou nenhum); exclusões de acesso, fissuras e primário comparadas com propostas da mesma revisão, sem revelar identidade ou preço dos concorrentes ao pintor.
- Exclusões exigem confirmação e motivo; texto livre da proposta aguarda revisão. Sem prazo confirmado, motivo em falta ou revisão pendente, a seleção é recusada também pelo motor de estados.
- Conversas associadas à proposta: todos os textos anteriores às duas entregas são retidos; contactos reconhecidos são bloqueados. A gestão pode aprovar/rejeitar mensagens pendentes depois de rever o contexto. Pendentes e bloqueadas não aparecem na vista do destinatário. Sem anexos neste canal.
- Filtros demonstrativos cobrem emails, arroba/ponto, ligações, números separados, Unicode e números por extenso; consideram mensagens anteriores. Não constituem deteção infalível de dados pessoais.
- Esclarecimento declarado como alteração exige reconfirmação da proposta. A conversa não altera preço ou contrato; após contratação, usar adendas.
- Demonstração em memória/localStorage: os perfis não são autenticação e o estado completo existe no navegador. Produção requer servidor, autorização por objeto, fila privada, moderação contextual, proteção de todos os campos/anexos e auditoria. Não utilizar com dados reais.
- `npm test`: 29 testes, incluindo percursos de interface em DOM simulado. Sem QA visual em navegador real nesta entrega.

## Protótipo 05 — marketplace, prédios e perfis

A conta de cliente tem uma entidade administradora, vários prédios/condomínios e vários pedidos por prédio. Cada pedido mantém o motor de orçamento/contratação isolado. O seletor de obra muda o contexto sem partilhar propostas, saldos, mensagens ou fotografias entre pedidos. As fotos continuam apenas em memória e são separadas por obra.

O pintor entra em Oportunidades; pode filtrar zona/tipo, consultar convites, aceitar ou recusar interesse, enviar proposta e acompanhar a carteira. Convites são interações locais do protótipo para B12. Preferências são guardadas; sem motor automático de recomendações ou envio externo. Pedidos contratados, expirados ou por publicar não aparecem como oportunidades abertas.

Perfis privados para cliente, pintor e fornecedor: identidade fiscal, representante, contactos, atendimento, licença/habilitação declarada e referências documentais. Ficha do prédio: identidade própria do condomínio, morada, referência predial, representante, mandato e comprovativo. A seleção captura uma cópia dos dados contratuais, que não é alterada por edições posteriores de perfil. A morada e a identificação da contraparte continuam ocultas até às duas entregas iniciais.

Novos pedidos começam sem propostas e com levantamento por confirmar. Perfil/ficha podem ser guardados incompletos; a publicação demonstrativa exige identificação do prédio preenchida, e a seleção exige dados de identificação/representação das partes. Estes controlos não constituem validação legal, fiscal ou de poderes. NIF: apenas formato de 9 algarismos; país de referência Portugal.

Documentos: escolha local de PDF/JPG/PNG até 10 MB, referências guardadas no navegador, conteúdo apenas na sessão. Sem arquivo duradouro, OCR ou validação externa. Gestão pode simular revisão/correção, com estado explicitamente demonstrativo. Não usar documentos nem dados reais. Produção requer autenticação, isolamento de organizações, autorização por obra, upload privado duradouro e validação documental apropriada.

Verificação: 36 testes automáticos, incluindo percurso integrado em DOM simulado desde prédio novo até proposta e desbloqueio de contactos. Não foi possível realizar QA visual em navegador real nesta entrega.
